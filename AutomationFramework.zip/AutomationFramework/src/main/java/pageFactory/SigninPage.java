package pageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class SigninPage {

    public WebDriver driver;

    @FindBy(id = "user-name")
    public WebElement userName;  //driver.findElement(By.id("user-name"));

    @FindBy(id = "password")
    public WebElement password;

    @FindBy(id = "login-button")
    public WebElement loginButton;
    public SigninPage(WebDriver driver) {
        this.driver = driver;
    }

    public SigninPage enterUserName(String username) {
       userName.sendKeys(username);
       return this;
    }
    public SigninPage enterPassword(String passWord) {
        password.sendKeys(passWord);
        return this;
    }
    public SigninPage clickSignIn() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        wait.until(driver -> loginButton.isEnabled());
        loginButton.click();
        return this;
    }

    public InventoryPage gotoInventoryPage(){
        clickSignIn();
        return PageFactory.initElements(driver, InventoryPage.class);
    }

}
