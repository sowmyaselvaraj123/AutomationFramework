package pageFactory;

import base.DriverUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class InventoryPage {
    public WebDriver driver;
    @FindBy(className = "product_sort_container")
    public WebElement sort;

    @FindBy(xpath = "(//button[@id='add-to-cart-sauce-labs-backpack'])[1]")
    public WebElement addToCart;

    public InventoryPage clickSort() {
        new DriverUtils(driver).selectOption(driver, "Name (A to Z)",this.sort);
        return this;
    }
    public InventoryPage clickAddToCart() {
        new DriverUtils(driver).clickAt(driver, this.addToCart);
        return this;
    }
}
