package testcases;

import base.baseclass;
import org.testng.annotations.Test;
import pageFactory.InventoryPage;
import pageFactory.SigninPage;

import java.sql.SQLOutput;

public class RegressionTestcase extends baseclass {

    @Test
    public void testSignInandSignOut(){

        SigninPage signinpage=gotoHomepage();

        InventoryPage inventorypage=signinpage
                .enterUserName("standard_user")
                .enterPassword("secret_sauce")
                .gotoInventoryPage();

    }

}
